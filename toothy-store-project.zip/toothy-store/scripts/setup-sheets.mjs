import { google } from "googleapis";
import "dotenv/config";

const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
const key = process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, "\n");
const spreadsheetId = process.env.GOOGLE_SHEET_ID;
if (!email || !key || !spreadsheetId) throw new Error("กรุณาตั้งค่า GOOGLE_SERVICE_ACCOUNT_EMAIL, GOOGLE_PRIVATE_KEY และ GOOGLE_SHEET_ID ก่อน");
const auth = new google.auth.JWT({ email, key, scopes: ["https://www.googleapis.com/auth/spreadsheets"] });
const sheets = google.sheets({ version: "v4", auth });
const spreadsheet = await sheets.spreadsheets.get({ spreadsheetId });
const existing = new Set((spreadsheet.data.sheets || []).map(s => s.properties?.title));
const names = ["Products", "Orders", "Order_Items"];
const add = names.filter(n => !existing.has(n));
if (add.length) await sheets.spreadsheets.batchUpdate({ spreadsheetId, requestBody: { requests: add.map(title => ({ addSheet: { properties: { title } } })) } });
await sheets.spreadsheets.values.update({ spreadsheetId, range: "Products!A1:F3", valueInputOption: "USER_ENTERED", requestBody: { values: [
  ["SKU", "Name", "Description", "Price", "Stock", "Image"],
  ["TB001", "Soft Clean", "ขนแปรงนุ่มพิเศษ อ่อนโยนต่อเหงือก ใช้ได้ทุกวัน", 59, 100, "/images/toothbrush-soft.svg"],
  ["TB002", "Charcoal Clean", "ขนแปรงผสมชาร์โคล ทำความสะอาดอย่างมั่นใจ", 89, 80, "/images/toothbrush-charcoal.svg"]
] } });
await sheets.spreadsheets.values.update({ spreadsheetId, range: "Orders!A1:O1", valueInputOption: "USER_ENTERED", requestBody: { values: [["OrderID","CreatedAt","CustomerName","Phone","Address","Subdistrict","District","Province","PostalCode","ItemsJson","Total","Status","TrackingNo","Carrier","Note"]] } });
await sheets.spreadsheets.values.update({ spreadsheetId, range: "Order_Items!A1:G1", valueInputOption: "USER_ENTERED", requestBody: { values: [["OrderID","SKU","ProductName","Qty","UnitPrice","LineTotal","CreatedAt"]] } });
console.log("ตั้งค่า Google Sheets เรียบร้อย: Products, Orders, Order_Items");
