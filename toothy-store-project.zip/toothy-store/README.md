# TOOTHY — Smile Everyday

โปรเจกต์ร้านค้าออนไลน์แปรงสีฟันแบบ Full-stack สร้างด้วย Next.js และ Google Sheets

## ฟีเจอร์
- Landing page สไตล์ Modern Minimal พร้อมสินค้า 2 SKU
- ตะกร้าสินค้าและ Checkout พร้อมตรวจสอบข้อมูลจัดส่ง
- บันทึกคำสั่งซื้อและรายการสินค้าใน Google Sheets
- หักสต็อกเมื่อมีคำสั่งซื้อ
- หน้าผู้ดูแล `/admin` สำหรับดูออเดอร์ ค้นหา เปลี่ยนสถานะ และพิมพ์ใบจ่าหน้าพัสดุ
- ไฟล์ภาพสินค้าอยู่แยกใน `public/images/`

> หมายเหตุ: ระบบนี้เป็น starter project สำหรับงานเรียน/ร้านค้าขนาดเล็ก การตัดสต็อกผ่าน Google Sheets ไม่ใช่ transaction แบบฐานข้อมูล หากมีคำสั่งซื้อพร้อมกันจำนวนมากควรย้ายไปใช้ฐานข้อมูลที่รองรับ transaction และเพิ่มระบบชำระเงิน/เชื่อมขนส่งจริง

## 1) เตรียม Google Sheets
1. สร้าง Google Spreadsheet ใหม่ ตั้งชื่อ `TOOTHY Store`.
2. คัดลอก Spreadsheet ID จาก URL รูปแบบ `https://docs.google.com/spreadsheets/d/SPREADSHEET_ID/edit`.
3. ไปที่ Google Cloud Console สร้าง Project และเปิดใช้งาน **Google Sheets API**.
4. สร้าง Service Account แล้วสร้าง JSON key ดาวน์โหลดเก็บไว้เป็นความลับ.
5. นำอีเมล Service Account (รูปแบบ `...@...iam.gserviceaccount.com`) ไปแชร์ Spreadsheet โดยให้สิทธิ์ **Editor**.
6. คัดลอก `.env.example` เป็น `.env.local` แล้วกรอกค่าต่อไปนี้:
   - `GOOGLE_SHEET_ID`
   - `GOOGLE_SERVICE_ACCOUNT_EMAIL`
   - `GOOGLE_PRIVATE_KEY` (นำค่า `private_key` จาก JSON มาใส่ โดยคง `\n` หรือใช้รูปแบบบรรทัดใหม่)
   - `ADMIN_KEY` (ตั้งรหัสยาวและเดายาก)
7. ติดตั้ง dependencies และสร้างแท็บ/หัวตาราง:
   ```bash
   npm install
   npm install dotenv
   npm run setup:sheets
   ```
   สคริปต์จะสร้างแท็บ `Products`, `Orders`, `Order_Items` และใส่สินค้าเริ่มต้น TB001/TB002

## 2) รันในเครื่อง
```bash
npm install
npm install dotenv
npm run dev
```
เปิด http://localhost:3000

หน้าร้าน: `/`
หลังบ้าน: `/admin` (ใช้ค่า `ADMIN_KEY`)

## 3) อัปโหลด GitHub
1. สร้าง repository ใหม่บน GitHub เช่น `toothy-store`.
2. ห้ามอัปโหลด `.env.local` หรือ Service Account JSON ขึ้น GitHub.
3. รัน:
   ```bash
   git init
   git add .
   git commit -m "Initial TOOTHY store"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/toothy-store.git
   git push -u origin main
   ```

## 4) Deploy บน Vercel
1. เข้า https://vercel.com และเลือก **Add New → Project**.
2. Import repository `toothy-store`.
3. เพิ่ม Environment Variables ใน Vercel Project Settings → Environment Variables:
   - `GOOGLE_SHEET_ID`
   - `GOOGLE_SERVICE_ACCOUNT_EMAIL`
   - `GOOGLE_PRIVATE_KEY`
   - `ADMIN_KEY`
4. Deploy และเปิด URL ที่ Vercel สร้างให้.
5. ทดสอบสั่งซื้อจริงหนึ่งรายการ แล้วตรวจสอบแถวใหม่ใน `Orders` และ `Order_Items` รวมถึงสต็อกใน `Products`.

## โครงสร้าง Google Sheets

### Products
`SKU | Name | Description | Price | Stock | Image`

### Orders
`OrderID | CreatedAt | CustomerName | Phone | Address | Subdistrict | District | Province | PostalCode | ItemsJson | Total | Status | TrackingNo | Carrier | Note`

### Order_Items
`OrderID | SKU | ProductName | Qty | UnitPrice | LineTotal | CreatedAt`

## Workflow หลังบ้าน
- `รอหยิบสินค้า` → พนักงานหยิบ SKU และจำนวนตาม Picking list
- `กำลังแพ็ก` → ตรวจสอบสินค้าและแพ็กลงกล่อง
- `พร้อมจัดส่ง` → พิมพ์ใบจ่าหน้าพัสดุจากปุ่มในออเดอร์
- `จัดส่งแล้ว` → เปลี่ยนสถานะหลังส่งมอบให้ขนส่ง

ใบจ่าหน้าที่พิมพ์จากระบบเป็นเอกสารสำหรับแปะหน้ากล่อง ไม่ใช่ใบปะหน้าที่มีบาร์โค้ดจากบริษัทขนส่ง ต้องนำข้อมูลไปสร้าง shipment ในระบบของผู้ให้บริการขนส่งเพื่อรับ tracking number จริง

## ข้อควรทราบ
- ราคาสินค้าใน API อ้างอิงจาก Google Sheets ฝั่ง server ไม่เชื่อราคาที่ส่งมาจาก browser.
- อย่า commit `.env.local`, Service Account key หรือเปิดเผย `ADMIN_KEY`.
- ควรเปลี่ยน `ADMIN_KEY` ให้เป็น secret ที่ยาวและสุ่มก่อนใช้งานจริง.
- เพิ่มระบบชำระเงิน, การยืนยันคำสั่งซื้อ, การคืนสต็อกเมื่อยกเลิก และการเชื่อม API ขนส่งก่อนเปิดร้านเชิงพาณิชย์.
