import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "TOOTHY — Smile Everyday",
  description: "แปรงสีฟันคุณภาพดี ดูแลรอยยิ้มของคุณทุกวัน"
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="th"><body>{children}</body></html>;
}
