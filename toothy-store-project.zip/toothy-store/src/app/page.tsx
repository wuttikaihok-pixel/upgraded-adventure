 "use client";
import { useEffect, useMemo, useState } from "react";
import { ArrowRight, Check, ChevronDown, Menu, Minus, Plus, ShoppingBag, Smile, Sparkles, X } from "lucide-react";
import type { Product } from "@/lib/types";

type Cart = Record<string, number>;
const fallback: Product[] = [
  { sku: "TB001", name: "Soft Clean", description: "ขนแปรงนุ่มพิเศษ อ่อนโยนต่อเหงือก ใช้ได้ทุกวัน", price: 59, stock: 100, image: "/images/toothbrush-soft.svg" },
  { sku: "TB002", name: "Charcoal Clean", description: "ขนแปรงผสมชาร์โคล ทำความสะอาดอย่างมั่นใจ", price: 89, stock: 80, image: "/images/toothbrush-charcoal.svg" }
];
const money = (n: number) => new Intl.NumberFormat("th-TH", { style: "currency", currency: "THB", maximumFractionDigits: 0 }).format(n);

export default function Home() {
  const [products, setProducts] = useState<Product[]>(fallback);
  const [cart, setCart] = useState<Cart>({});
  const [checkout, setCheckout] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [form, setForm] = useState({ name: "", phone: "", address: "", subdistrict: "", district: "", province: "", postalCode: "" });

  useEffect(() => { fetch("/api/products").then(r => r.json()).then(data => { if (Array.isArray(data) && data.length) setProducts(data); }).catch(() => {}); }, []);
  const count = Object.values(cart).reduce((a, b) => a + b, 0);
  const total = useMemo(() => products.reduce((sum, p) => sum + p.price * (cart[p.sku] || 0), 0), [products, cart]);
  const change = (sku: string, delta: number) => setCart(old => {
    const product = products.find(p => p.sku === sku);
    const next = Math.max(0, Math.min(product?.stock ?? 99, (old[sku] || 0) + delta));
    return { ...old, [sku]: next };
  });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      const items = Object.entries(cart).filter(([, qty]) => qty > 0).map(([sku, qty]) => ({ sku, qty }));
      const res = await fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ customer: form, items }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "สั่งซื้อไม่สำเร็จ");
      setMessage(`สั่งซื้อสำเร็จ! เลขคำสั่งซื้อ ${data.orderId} ยอดชำระ ${money(data.total)} กรุณารอร้านค้าติดต่อกลับเพื่อยืนยันการชำระเงิน`);
      setCart({}); setCheckout(false);
    } catch (err) { setMessage(err instanceof Error ? err.message : "เกิดข้อผิดพลาด"); }
    finally { setBusy(false); }
  };
  const setField = (key: keyof typeof form, value: string) => setForm(old => ({ ...old, [key]: value }));

  return <main>
    <header className="site-header">
      <a href="#" className="brand"><span className="brand-mark"><Smile size={22}/></span> toothy<span className="brand-dot">.</span></a>
      <nav className={menuOpen ? "nav open" : "nav"}><a href="#products" onClick={() => setMenuOpen(false)}>สินค้า</a><a href="#why" onClick={() => setMenuOpen(false)}>ทำไมต้อง TOOTHY</a><a href="#footer" onClick={() => setMenuOpen(false)}>ติดต่อเรา</a></nav>
      <div className="header-actions"><button className="cart-button" onClick={() => setCheckout(true)}><ShoppingBag size={18}/> <span>ตะกร้า</span><b>{count}</b></button><button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="เมนู">{menuOpen ? <X/> : <Menu/>}</button></div>
    </header>

    <section className="hero">
      <div className="hero-copy"><div className="eyebrow"><Sparkles size={14}/> SMALL HABITS, BIG SMILES</div><h1>เริ่มต้นรอยยิ้มที่ดี<br/><span>ในทุก ๆ วัน</span></h1><p>ดูแลสุขภาพช่องปากให้ง่ายขึ้น ด้วยแปรงสีฟันที่ใส่ใจทุกรายละเอียด อ่อนโยน สะอาด และพร้อมอยู่เคียงข้างรอยยิ้มของคุณ</p><a className="primary-button" href="#products">เลือกแปรงสีฟันของคุณ <ArrowRight size={17}/></a><div className="hero-note"><span><Check size={14}/> ขนแปรงนุ่ม</span><span><Check size={14}/> ดีไซน์จับถนัดมือ</span></div></div>
      <div className="hero-art"><div className="hero-blob"></div><div className="hero-sun"></div><img src="/images/hero-toothbrush.svg" alt="แปรงสีฟัน TOOTHY" /><div className="floating-note"><span className="floating-icon"><Smile size={19}/></span><span><b>A happier smile</b><small>starts with TOOTHY</small></span></div><div className="hero-stamp">SMILE<br/>EVERYDAY</div></div>
    </section>

    <section className="trust-strip"><div><b>01</b><span>เลือกขนแปรงที่ใช่</span></div><div><b>02</b><span>ดูแลฟันอย่างอ่อนโยน</span></div><div><b>03</b><span>ยิ้มได้อย่างมั่นใจ</span></div></section>

    <section id="products" className="products-section"><div className="section-heading"><div><div className="eyebrow">OUR COLLECTION</div><h2>แปรงที่ใช่ <span>สำหรับคุณ</span></h2></div><p>เพราะรอยยิ้มที่ดี เริ่มจากการดูแลตัวเองในทุกวัน</p></div><div className="product-grid">
      {products.map((p, index) => <article className="product-card" key={p.sku}><div className={`product-image ${index % 2 ? "dark-product" : ""}`}><span className="product-tag">{index === 0 ? "BEST SELLER" : "DAILY CARE"}</span><img src={p.image} alt={p.name}/></div><div className="product-info"><div><small>{p.sku}</small><h3>{p.name}</h3><p>{p.description}</p></div><div className="product-bottom"><strong>{money(p.price)}</strong><button onClick={() => change(p.sku, 1)} disabled={p.stock < 1}><Plus size={17}/> เพิ่มลงตะกร้า</button></div><small className="stock-note">{p.stock > 0 ? `มีสินค้า ${p.stock} ชิ้น` : "สินค้าหมด"}</small></div></article>)}
    </div></section>

    <section id="why" className="why-section"><div className="why-art"><div className="why-circle"><img src="/images/toothbrush-soft.svg" alt="แปรงสีฟัน"/></div><span className="why-spark one">✳</span><span className="why-spark two">✦</span></div><div className="why-copy"><div className="eyebrow">WHY TOOTHY?</div><h2>เรื่องเล็ก ๆ ที่สร้าง<br/><span>รอยยิ้มที่ยิ่งใหญ่</span></h2><p>เราเชื่อว่าการดูแลช่องปากไม่จำเป็นต้องซับซ้อน TOOTHY จึงคัดสรรแปรงสีฟันที่ใช้งานง่าย ดีไซน์เรียบสวย และเหมาะกับกิจวัตรประจำวันของทุกคน</p><div className="feature-list"><div><span>01</span><b>Soft touch</b><small>สัมผัสนุ่ม อ่อนโยน</small></div><div><span>02</span><b>Easy grip</b><small>ด้ามจับกระชับมือ</small></div><div><span>03</span><b>Everyday care</b><small>ดูแลได้ทุกวัน</small></div></div></div></section>

    <section className="cta-section"><div className="eyebrow">YOUR SMILE MATTERS</div><h2>พร้อมเริ่มต้นวันใหม่<br/>ด้วยรอยยิ้มแล้วหรือยัง?</h2><a className="light-button" href="#products">เลือกซื้อสินค้า <ArrowRight size={17}/></a><span className="cta-decoration">☺</span></section>
    <footer id="footer"><a href="#" className="brand"><span className="brand-mark"><Smile size={20}/></span> toothy<span className="brand-dot">.</span></a><span>Smile everyday. © {new Date().getFullYear()} TOOTHY Store</span><a href="/admin">สำหรับผู้ดูแลร้าน</a></footer>

    {message && <div className="toast" role="status"><Check size={18}/>{message}<button onClick={() => setMessage("")}><X size={16}/></button></div>}
    {checkout && <div className="modal-backdrop" onClick={() => setCheckout(false)}><section className="checkout-modal" onClick={e => e.stopPropagation()}><div className="modal-head"><div><div className="eyebrow">YOUR ORDER</div><h2>ตะกร้าสินค้า</h2></div><button className="icon-button" onClick={() => setCheckout(false)}><X/></button></div>
      {count === 0 ? <div className="empty-cart"><ShoppingBag size={34}/><p>ยังไม่มีสินค้าในตะกร้า</p><button className="primary-button" onClick={() => setCheckout(false)}>เลือกสินค้า</button></div> : <><div className="cart-lines">{products.filter(p => cart[p.sku]).map(p => <div className="cart-line" key={p.sku}><img src={p.image} alt=""/><div className="cart-line-name"><b>{p.name}</b><small>{money(p.price)} / ชิ้น</small></div><div className="qty-control"><button onClick={() => change(p.sku, -1)}><Minus size={14}/></button><b>{cart[p.sku]}</b><button onClick={() => change(p.sku, 1)}><Plus size={14}/></button></div><strong>{money(p.price * cart[p.sku])}</strong></div>)}</div><div className="cart-total"><span>ยอดรวมสินค้า</span><b>{money(total)}</b></div><form className="checkout-form" onSubmit={submit}><h3>ข้อมูลสำหรับจัดส่ง</h3><div className="form-grid"><label>ชื่อ-นามสกุล<input required value={form.name} onChange={e => setField("name", e.target.value)} placeholder="ชื่อผู้รับ"/></label><label>เบอร์โทรศัพท์<input required inputMode="tel" pattern="[0-9+ -]{9,15}" value={form.phone} onChange={e => setField("phone", e.target.value)} placeholder="08X-XXX-XXXX"/></label><label className="full">ที่อยู่ / บ้านเลขที่ / ถนน<input required value={form.address} onChange={e => setField("address", e.target.value)} placeholder="บ้านเลขที่ หมู่บ้าน ถนน"/></label><label>แขวง / ตำบล<input required value={form.subdistrict} onChange={e => setField("subdistrict", e.target.value)}/></label><label>เขต / อำเภอ<input required value={form.district} onChange={e => setField("district", e.target.value)}/></label><label>จังหวัด<input required value={form.province} onChange={e => setField("province", e.target.value)}/></label><label>รหัสไปรษณีย์<input required inputMode="numeric" pattern="[0-9]{5}" maxLength={5} value={form.postalCode} onChange={e => setField("postalCode", e.target.value)}/></label></div><button className="primary-button submit-order" disabled={busy}>{busy ? "กำลังบันทึก..." : <>ยืนยันคำสั่งซื้อ · {money(total)} <ArrowRight size={17}/></>}</button><small className="secure-note">ข้อมูลคำสั่งซื้อจะถูกบันทึกลง Google Sheets</small></form></>}
    </section></div>}
  </main>;
}
