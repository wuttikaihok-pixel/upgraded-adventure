import { NextRequest, NextResponse } from "next/server";
import { appendOrder, readProducts, updateStock } from "@/lib/sheets";
import type { Customer, Order, OrderItem } from "@/lib/types";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as { customer: Customer; items: { sku: string; qty: number }[] };
    const c = body.customer;
    if (!c?.name || !c.phone || !c.address || !c.subdistrict || !c.district || !c.province || !/^\d{5}$/.test(c.postalCode || "")) {
      return NextResponse.json({ error: "กรุณากรอกข้อมูลผู้รับให้ครบ และรหัสไปรษณีย์ 5 หลัก" }, { status: 400 });
    }
    if (!Array.isArray(body.items) || !body.items.length) return NextResponse.json({ error: "ไม่มีสินค้าในตะกร้า" }, { status: 400 });

    const products = await readProducts();
    const orderItems: OrderItem[] = body.items.map(line => {
      const product = products.find(p => p.sku === line.sku);
      const qty = Math.floor(Number(line.qty));
      if (!product || !Number.isFinite(qty) || qty < 1) throw new Error("รายการสินค้าไม่ถูกต้อง");
      if (product.stock < qty) throw new Error(`สินค้า ${product.name} คงเหลือไม่เพียงพอ`);
      return { sku: product.sku, name: product.name, qty, unitPrice: product.price, lineTotal: product.price * qty };
    });
    const unique = new Set(orderItems.map(i => i.sku));
    if (unique.size !== orderItems.length) throw new Error("พบ SKU ซ้ำในตะกร้า กรุณาลองใหม่");
    const order: Order = {
      orderId: `TO-${Date.now().toString().slice(-8)}`,
      createdAt: new Date().toISOString(),
      customer: c, items: orderItems, total: orderItems.reduce((sum, i) => sum + i.lineTotal, 0),
      status: "รอหยิบสินค้า"
    };
    // Save order first; then deduct inventory. For high-volume stores, use a transactional database.
    await appendOrder(order);
    const updated = products.map(p => {
      const line = orderItems.find(i => i.sku === p.sku);
      return line ? { ...p, stock: p.stock - line.qty } : p;
    });
    await updateStock(updated);
    return NextResponse.json({ orderId: order.orderId, total: order.total });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "บันทึกคำสั่งซื้อไม่สำเร็จ" }, { status: 400 });
  }
}
