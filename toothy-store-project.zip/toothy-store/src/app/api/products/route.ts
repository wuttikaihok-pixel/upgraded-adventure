import { NextResponse } from "next/server";
import { readProducts } from "@/lib/sheets";
export const dynamic = "force-dynamic";
export async function GET() {
  try { return NextResponse.json(await readProducts()); }
  catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "โหลดสินค้าไม่สำเร็จ" }, { status: 500 }); }
}
