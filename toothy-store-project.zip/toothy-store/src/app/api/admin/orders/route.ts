import { NextRequest, NextResponse } from "next/server";
import { readOrders, setOrderStatus } from "@/lib/sheets";
export const dynamic = "force-dynamic";
function authorized(request: NextRequest) {
  const expected = process.env.ADMIN_KEY;
  return !!expected && request.headers.get("x-admin-key") === expected;
}
export async function GET(request: NextRequest) {
  if (!authorized(request)) return NextResponse.json({ error: "รหัสผู้ดูแลไม่ถูกต้อง" }, { status: 401 });
  try { return NextResponse.json(await readOrders()); }
  catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "โหลดคำสั่งซื้อไม่สำเร็จ" }, { status: 500 }); }
}
export async function PATCH(request: NextRequest) {
  if (!authorized(request)) return NextResponse.json({ error: "รหัสผู้ดูแลไม่ถูกต้อง" }, { status: 401 });
  try {
    const { orderId, status } = await request.json();
    const allowed = ["รอหยิบสินค้า", "กำลังแพ็ก", "พร้อมจัดส่ง", "จัดส่งแล้ว", "ยกเลิก"];
    if (!orderId || !allowed.includes(status)) return NextResponse.json({ error: "ข้อมูลสถานะไม่ถูกต้อง" }, { status: 400 });
    await setOrderStatus(orderId, status);
    return NextResponse.json({ ok: true });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "อัปเดตไม่สำเร็จ" }, { status: 400 }); }
}
