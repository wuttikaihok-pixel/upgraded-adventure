 "use client";
import { useEffect, useState } from "react";
import { ArrowLeft, ClipboardList, LockKeyhole, PackageCheck, Printer, RefreshCw, Search } from "lucide-react";
import type { Order } from "@/lib/types";
const money = (n: number) => new Intl.NumberFormat("th-TH", { style: "currency", currency: "THB", maximumFractionDigits: 0 }).format(n);
const statuses = ["รอหยิบสินค้า", "กำลังแพ็ก", "พร้อมจัดส่ง", "จัดส่งแล้ว", "ยกเลิก"];
export default function Admin() {
  const [key, setKey] = useState("");
  const [savedKey, setSavedKey] = useState("");
  const [orders, setOrders] = useState<Order[]>([]);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  async function load(secret = savedKey) {
    if (!secret) return; setLoading(true); setError("");
    try { const r = await fetch("/api/admin/orders", { headers: { "x-admin-key": secret }, cache: "no-store" }); const d = await r.json(); if (!r.ok) throw new Error(d.error); setOrders(d); }
    catch (e) { setError(e instanceof Error ? e.message : "โหลดข้อมูลไม่สำเร็จ"); }
    finally { setLoading(false); }
  }
  useEffect(() => { if (savedKey) load(savedKey); }, [savedKey]);
  async function update(orderId: string, status: string) {
    const r = await fetch("/api/admin/orders", { method: "PATCH", headers: { "Content-Type": "application/json", "x-admin-key": savedKey }, body: JSON.stringify({ orderId, status }) });
    const d = await r.json(); if (!r.ok) { setError(d.error); return; } load();
  }
  const filtered = orders.filter(o => `${o.orderId} ${o.customer.name} ${o.customer.phone}`.toLowerCase().includes(query.toLowerCase()));
  if (!savedKey) return <main className="admin-login"><a href="/" className="back-link"><ArrowLeft size={16}/> กลับหน้าร้าน</a><div className="login-card"><div className="login-icon"><LockKeyhole/></div><div className="eyebrow">TOOTHY STORE MANAGEMENT</div><h1>เข้าสู่ระบบหลังบ้าน</h1><p>กรอกรหัสผู้ดูแลร้านเพื่อดูและจัดการคำสั่งซื้อ</p><form onSubmit={e => { e.preventDefault(); setSavedKey(key); }}><label>Admin key<input type="password" value={key} onChange={e => setKey(e.target.value)} required placeholder="รหัสผู้ดูแลร้าน"/></label><button className="primary-button">เข้าสู่ระบบ <ArrowLeft size={16}/></button></form></div></main>;
  return <main className="admin-page"><header className="admin-header"><a href="/" className="brand"><span className="brand-mark"><PackageCheck size={20}/></span> toothy<span className="brand-dot">.</span></a><div><span>STORE MANAGEMENT</span><button onClick={() => { setSavedKey(""); setKey(""); }}>ออกจากระบบ</button></div></header><section className="admin-content"><div className="admin-title"><div><div className="eyebrow">ORDER FULFILLMENT</div><h1>จัดการคำสั่งซื้อ</h1><p>ตรวจสอบ หยิบสินค้า แพ็ก และพิมพ์ใบจ่าหน้าพัสดุ</p></div><button className="refresh-button" onClick={() => load()}><RefreshCw size={16}/> รีเฟรช</button></div>
    <div className="admin-stats"><div><ClipboardList/><span>คำสั่งซื้อทั้งหมด</span><b>{orders.length}</b></div><div><PackageCheck/><span>รอหยิบสินค้า</span><b>{orders.filter(o => o.status === statuses[0]).length}</b></div><div><Printer/><span>พร้อมจัดส่ง</span><b>{orders.filter(o => o.status === statuses[2]).length}</b></div></div>
    <div className="orders-toolbar"><h2>รายการออเดอร์</h2><label className="search-box"><Search size={17}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="ค้นหาเลขออเดอร์ / ชื่อ / เบอร์โทร"/></label></div>
    {error && <p className="admin-error">{error}</p>}
    {loading ? <p>กำลังโหลดข้อมูล...</p> : filtered.length === 0 ? <div className="admin-empty">ยังไม่มีคำสั่งซื้อที่ตรงกับการค้นหา</div> : <div className="order-list">{filtered.map(order => <article className="order-card" key={order.orderId}><div className="order-card-top"><div><b>{order.orderId}</b><small>{new Date(order.createdAt).toLocaleString("th-TH")}</small></div><span className={`status-pill status-${statuses.indexOf(order.status)}`}>{order.status}</span></div><div className="order-details"><div><small>ผู้รับ</small><b>{order.customer.name}</b><span>{order.customer.phone}</span></div><div><small>ที่อยู่จัดส่ง</small><span>{order.customer.address} แขวง/ตำบล {order.customer.subdistrict} เขต/อำเภอ {order.customer.district} จังหวัด{order.customer.province} {order.customer.postalCode}</span></div></div><div className="pick-list"><h3>รายการหยิบสินค้า (Picking list)</h3>{order.items.map(item => <div key={item.sku}><span><b>{item.sku}</b> · {item.name}</span><strong>× {item.qty}</strong></div>)}</div><div className="order-card-bottom"><div><small>ยอดรวมสินค้า</small><b>{money(order.total)}</b></div><div className="order-actions"><select value={order.status} onChange={e => update(order.orderId, e.target.value)} aria-label="สถานะคำสั่งซื้อ">{statuses.map(s => <option key={s}>{s}</option>)}</select><button className="print-button" onClick={(e) => { const card = e.currentTarget.closest(".order-card"); document.querySelectorAll(".order-card").forEach(el => el.classList.remove("print-target")); card?.classList.add("print-target"); window.print(); }}><Printer size={16}/> พิมพ์ใบจ่าหน้า</button></div></div><div className="shipping-label"><div className="label-brand">TOOTHY <span>SHIPPING LABEL</span></div><div className="label-row"><small>ผู้รับ (SHIP TO)</small><b>{order.customer.name}</b><span>{order.customer.phone}</span><p>{order.customer.address} แขวง/ตำบล {order.customer.subdistrict} เขต/อำเภอ {order.customer.district} จังหวัด{order.customer.province} {order.customer.postalCode}</p></div><div className="label-footer"><span>ORDER: {order.orderId}</span><span>จำนวน {order.items.reduce((s, i) => s + i.qty, 0)} ชิ้น</span></div></div></article>)}</div>}
    </section></main>;
}
