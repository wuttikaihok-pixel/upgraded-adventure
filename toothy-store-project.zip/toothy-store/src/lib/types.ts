export type Product = {
  sku: string; name: string; description: string; price: number; stock: number; image: string;
};
export type CartLine = { sku: string; qty: number };
export type Customer = {
  name: string; phone: string; address: string; subdistrict: string;
  district: string; province: string; postalCode: string;
};
export type OrderItem = {
  sku: string; name: string; qty: number; unitPrice: number; lineTotal: number;
};
export type Order = {
  orderId: string; createdAt: string; customer: Customer; items: OrderItem[];
  total: number; status: string;
};
