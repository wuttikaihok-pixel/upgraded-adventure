import { google } from "googleapis";
import type { Order, Product, Customer, OrderItem } from "./types";

const SCOPES = ["https://www.googleapis.com/auth/spreadsheets"];

function getSheets() {
  const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
  const key = process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, "\n");
  const spreadsheetId = process.env.GOOGLE_SHEET_ID;
  if (!email || !key || !spreadsheetId) {
    throw new Error("Google Sheets is not configured. Set GOOGLE_SHEET_ID, GOOGLE_SERVICE_ACCOUNT_EMAIL and GOOGLE_PRIVATE_KEY.");
  }
  const auth = new google.auth.JWT({ email, key, scopes: SCOPES });
  return { api: google.sheets({ version: "v4", auth }), spreadsheetId };
}

export async function readProducts(): Promise<Product[]> {
  const { api, spreadsheetId } = getSheets();
  const result = await api.spreadsheets.values.get({ spreadsheetId, range: "Products!A2:F" });
  return (result.data.values || []).filter(r => r[0]).map(r => ({
    sku: String(r[0]), name: String(r[1] || ""), description: String(r[2] || ""),
    price: Number(r[3] || 0), stock: Number(r[4] || 0), image: String(r[5] || "/images/toothbrush-soft.svg")
  }));
}

export async function appendOrder(order: Order) {
  const { api, spreadsheetId } = getSheets();
  const customer = order.customer;
  await api.spreadsheets.values.append({
    spreadsheetId, range: "Orders!A:O", valueInputOption: "USER_ENTERED", insertDataOption: "INSERT_ROWS",
    requestBody: { values: [[
      order.orderId, order.createdAt, customer.name, customer.phone, customer.address,
      customer.subdistrict, customer.district, customer.province, customer.postalCode,
      JSON.stringify(order.items), order.total, order.status, "", "", ""
    ]] }
  });
  await api.spreadsheets.values.append({
    spreadsheetId, range: "Order_Items!A:G", valueInputOption: "USER_ENTERED", insertDataOption: "INSERT_ROWS",
    requestBody: { values: order.items.map(i => [order.orderId, i.sku, i.name, i.qty, i.unitPrice, i.lineTotal, order.createdAt]) }
  });
}

export async function updateStock(products: Product[]) {
  const { api, spreadsheetId } = getSheets();
  if (!products.length) return;
  await api.spreadsheets.values.update({
    spreadsheetId, range: "Products!A2:F", valueInputOption: "USER_ENTERED",
    requestBody: { values: products.map(p => [p.sku, p.name, p.description, p.price, p.stock, p.image]) }
  });
}

export async function readOrders(): Promise<Order[]> {
  const { api, spreadsheetId } = getSheets();
  const result = await api.spreadsheets.values.get({ spreadsheetId, range: "Orders!A2:O" });
  return (result.data.values || []).filter(r => r[0]).map(r => {
    let items: OrderItem[] = [];
    try { items = JSON.parse(String(r[9] || "[]")); } catch {}
    const customer: Customer = {
      name: String(r[2] || ""), phone: String(r[3] || ""), address: String(r[4] || ""),
      subdistrict: String(r[5] || ""), district: String(r[6] || ""), province: String(r[7] || ""),
      postalCode: String(r[8] || "")
    };
    return { orderId: String(r[0]), createdAt: String(r[1]), customer, items,
      total: Number(r[10] || 0), status: String(r[11] || "รอดำเนินการ") };
  }).reverse();
}

export async function setOrderStatus(orderId: string, status: string) {
  const { api, spreadsheetId } = getSheets();
  const result = await api.spreadsheets.values.get({ spreadsheetId, range: "Orders!A:L" });
  const rows = result.data.values || [];
  const index = rows.findIndex((r, i) => i > 0 && String(r[0]) === orderId);
  if (index < 1) throw new Error("ไม่พบคำสั่งซื้อ");
  await api.spreadsheets.values.update({
    spreadsheetId, range: `Orders!L${index + 1}`, valueInputOption: "USER_ENTERED",
    requestBody: { values: [[status]] }
  });
}
